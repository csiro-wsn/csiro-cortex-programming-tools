#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#define _(x) x
